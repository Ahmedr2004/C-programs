#include<stdio.h>

int main()
{
    int m1[3][3] , m2[3][3];
    printf("Enter the elements of m1 \n");
    for(int a = 0 ; a<=2 ; a++)
    {
        for(int b = 0 ; b<=2 ; b++)
        {
            scanf("%d", &m1[a][b]);
        }
    }
    printf("Enter the elements of m2 \n");
    for(int a = 0 ; a<=2 ; a++)
    {
        for(int b = 0 ; b<=2 ; b++)
        {
            scanf("%d", &m2[a][b]);
        }
    }
    int m3[3][3];
    for(int i = 0 ; i<=2 ;i++)
    {
        for(int j = 0 ; j<=2 ; j++)
        {
            m3[i][j] = m1[i][j] + m2[i][j];
        }
    }
    printf("The addition of m1 and m2 is: \n");
    for(int i = 0 ; i<=2 ; i++){
        for(int j = 0 ; j<=2 ; j++){
            printf("%d\t", m3[i][j] );
        }
        printf("\n");
    }
}