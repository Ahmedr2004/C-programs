#include<stdio.h>
int Sum_Of_Diagonal(int m1[3][3]){
    int sum = 0;
    for(int i = 0 ; i<3 ; i++){
        sum += m1[i][i];
    }
    return sum;
}
int main()
{
    int m1[3][3] ;
    printf("Enter the elements of m1 \n");
    for(int a = 0 ; a<=2 ; a++)
    {
        for(int b = 0 ; b<=2 ; b++)
        {
            scanf("%d", &m1[a][b]);
        }
    }
    
    int p;
    p = Sum_Of_Diagonal(m1);
    printf("The sum of diagonal elements of the matrix is %d", p);
    return 0;
}