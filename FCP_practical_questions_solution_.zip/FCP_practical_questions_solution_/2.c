#include<stdio.h>

float Celsius_to_Fahrenheit(float c){
    float f = ((9/5)*c)+32;
    return f;
}

float Fahrenheit_to_Celsius(float f){
    float c = ((f-32)*(5/9));
    return c;
}

int main(){
    float c = Fahrenheit_to_Celsius(212.0);
    float f = Celsius_to_Fahrenheit(100.0);
    printf("Temperature in celsius =\n%f", c);
    printf("\nTemperature in fahrenheit =\n%f", f);
    return 0;
}